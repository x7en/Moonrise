HANDPICKED TEXTURES FOR THE ZOMBIE SURVIVAL GAME
=================================================

GHOSTS (Act 2 only)  -> ghosts/
  Horizontal sprite strips. Transparent background, 10 frames each, 10 FPS (100 ms/frame).
  Each ghost materializes, attacks, then dissolves. Blank frames were removed.

  ghost_scythe_strip.png        cell 80x50    10 frames   (standard ghost, scythe slash)   <- use as the main ghost
  ghost_lunge_strip.png         cell 120x42   10 frames   (lunge/dash attack)              <- optional second variant
  ghost_scythe_spike_strip.png  cell 131x87   10 frames   (scythe + spike eruption)        <- optional rare/strong variant

  The ghost body itself is only about 20-25 px tall in the source art, so scale in-engine
  with nearest-neighbour filtering to keep it crisp. Attack effects (slash, spike) are
  part of the animation, so a hit window should match the slash frames, not the whole strip.

INVENTORY MELEE ICONS (optional) -> weapons/
  knife_a.png 4x10   knife_b.png 6x11   hammer_club.png 33x9
  bat_red.png 31x12  bat_plain.png 36x10  sword_steel.png 39x5
  Cropped from The Ultimate Weapons Pack (48x24 cells). Side-view sprites.

BOOMERANG (phase 2, not used yet) -> placeholders/
  boomerang_placeholder.png 22x21. The weapons pack has no boomerang, so this is a simple
  hand-drawn stand-in. Replace it later with a final sprite if you find one.

CREDITS / LICENSES  (important)
  - Weapons: "The Ultimate Weapons Pack" by Jestan. The license asks for attribution to
    Jestan in the game credits. It may be used in commercial and non-commercial games.
    Do not redistribute the raw pack outside of a game.
  - Ghosts: "ghost_attacks" (Aseprite sheet, tags larry / besk / kevin). The zip had NO
    license or author file. Check the page you downloaded it from and confirm the license
    and credit before releasing the game publicly.
